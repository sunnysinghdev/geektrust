def remove_duplicates(l):
    return list(dict.fromkeys(l))