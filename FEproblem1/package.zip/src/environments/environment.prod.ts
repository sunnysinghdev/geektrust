export const environment = {
  production: true,
  apiEndpoint: "https://findfalcone.herokuapp.com/"
};
